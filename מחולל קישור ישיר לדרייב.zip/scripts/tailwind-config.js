tailwind.config = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        space: '#0f172a',
        neon: '#00ffc3',
        plasma: '#8b5cf6',
      },
      fontFamily: {
        sans: ['Rubik', 'sans-serif'],
      },
    },
  },
};

