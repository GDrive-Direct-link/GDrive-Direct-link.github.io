
const apiKey = 'AIzaSyCIP9bS1Togmb8ovDd18fM3QuZ3S3j_J4o';

function extractFileId(url) {
  const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
  return match ? match[1] : null;
}

function generateLink() {
  const url = document.getElementById('driveLink').value;
  const fileId = extractFileId(url);
  const output = document.getElementById('output');
  if (!fileId) {
    output.innerHTML = '⚠️ לא הצלחנו לזהות מזהה קובץ מהקישור הזה.';
    return;
  }

  const directLink = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${apiKey}`;
  output.innerHTML = `
    <p class="mb-2 break-all animate-pulse">📥 <a href="${directLink}" target="_blank" class="underline text-blue-600 dark:text-neon hover:text-blue-800 dark:hover:text-plasma transition">${directLink}</a></p>
    <button onclick="copyToClipboard('${directLink}')" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded transition">
      📋 העתק ללוח
    </button>
  `;

  saveToHistory(directLink);
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert("📋 הועתק!");
  });
}

function saveToHistory(link) {
  let history = JSON.parse(localStorage.getItem('driveHistory') || '[]');
  history = [link, ...history.filter(item => item !== link)].slice(0, 10);
  localStorage.setItem('driveHistory', JSON.stringify(history));
  renderHistory();
}

function renderHistory() {
  const history = JSON.parse(localStorage.getItem('driveHistory') || '[]');
  const list = document.getElementById('historyList');
  list.innerHTML = '';
  history.forEach(link => {
    const li = document.createElement('li');
    li.innerHTML = `<a href="${link}" class="underline text-blue-600 dark:text-neon hover:text-blue-800 dark:hover:text-plasma transition" target="_blank">${link}</a>`;
    list.appendChild(li);
  });
}

function toggleTheme() {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
}

function clearHistory() {
  if (confirm("אתה בטוח שאתה רוצה למחוק את ההיסטוריה? 😬")) {
    localStorage.removeItem('driveHistory');
    renderHistory();
  }
}

(function () {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
  }
})();

renderHistory();
